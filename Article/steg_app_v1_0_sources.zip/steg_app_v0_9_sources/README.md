Steg Studio is an image steganography software: it hides information in image files. You can do this by altering the least significant bit of the pixel 
bytes in an image. This changes the image in a way that may not be (too) noticeable to the human eye.

The actual steganography methods are found in the file "Karabow.Steg.Core/Steganographer.cs".

See the wiki for more info.